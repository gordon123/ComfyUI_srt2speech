any_typ = "*"
